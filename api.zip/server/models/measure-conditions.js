'use strict';

module.exports = function(Measureconditions) {

};
