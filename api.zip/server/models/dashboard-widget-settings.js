'use strict';

module.exports = function(Dashboardwidgetsettings) {

};
