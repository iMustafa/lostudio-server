'use strict';

module.exports = function(Notifications) {

};
