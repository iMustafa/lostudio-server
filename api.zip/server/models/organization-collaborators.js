'use strict';

module.exports = function (Organizationcollaborators) {
  
};
