'use strict';

module.exports = function(Userwidgetsettings) {

};
