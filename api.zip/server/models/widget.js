'use strict';

module.exports = function(Widget) {

};
