'use strict';

module.exports = function(Userdashboards) {

};
