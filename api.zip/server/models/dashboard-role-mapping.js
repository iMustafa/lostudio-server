'use strict';

module.exports = function (Dashboardrolemapping) {

};
